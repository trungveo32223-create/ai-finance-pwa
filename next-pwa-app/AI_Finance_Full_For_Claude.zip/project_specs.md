# 📖 AI FINANCE PWA - PROJECT SPECS
*(Tài liệu Đặc tả Dự án - Cập nhật liên tục)*

Tài liệu này là "Luật Chơi" bất di bất dịch của dự án. Mọi dòng code được viết ra đều phải tuân thủ tuyệt đối các quy tắc trong tài liệu này.

---

## 0. TỔNG QUAN DỰ ÁN (OVERVIEW)
- **Mục tiêu:** Xây dựng ứng dụng quản lý tài chính cá nhân siêu tốc qua giao diện Chat (PWA), dùng AI bóc tách ngôn ngữ tự nhiên để thay thế thao tác nhập liệu thủ công.
- **Trạng thái hiện tại:** Đã code xong tính năng của **Phase 1 & 2** (Ghi sổ và Xem báo cáo). Tuy nhiên hệ thống **chưa Test toàn diện** và **chưa Harness** (đánh giá sức chịu tải & rủi ro thực tế). **Dựng bộ test (các case R/S/D) và chạy PASS 100% là điều kiện BẮT BUỘC để gọi là DONE.**
- **Tech Stack:**
  - **Frontend / Backend:** Next.js (App Router), React, Tailwind CSS.
  - **Database:** Supabase (PostgreSQL).
  - **Trí Tuệ Nhân Tạo (AI):** Groq (Llama 3.3 70B) dùng cho Router, DeepSeek V3 dùng cho Worker bóc tách nghiệp vụ.
- **Mức độ Deploy (Production):** 
  - Source code đẩy thủ công lên **GitHub**.
  - Tự động Deploy CI/CD lên **Vercel** (Live URL).
  - Data thật lưu trên **Supabase**. Hỗ trợ cài đặt thành App trên điện thoại (PWA).

---

## 1. KIẾN TRÚC AI & LUỒNG XỬ LÝ (4 THÀNH PHẦN)
Hệ thống AI bóc tách tin nhắn gồm đúng 4 thành phần, được tinh gọn để xử lý song song và tối ưu chi phí:

```mermaid
graph TD
    U[User Input] --> R{Agent Router<br/>Llama 3.3 70B}
    
    R -->|Standard| S[Agent Standard<br/>DeepSeek V3]
    R -->|Debt| D[Agent Debt<br/>DeepSeek V3]
    R -->|Query| Q[Module Query<br/>SQL Thuần]
    R -->|Unclear| U2[Hỏi lại User]

    S --> DB[(Supabase DB)]
    D --> DB
    Q --> DB
```

**Vai trò cụ thể:**
1. **Agent_Router** (Llama 3.3 qua Groq): Nhận diện ý định, phân luồng tin nhắn, trích xuất tham số tra cứu. Nếu câu không rõ nghĩa -> Hỏi lại (Unclear).
2. **Agent_Standard** (DeepSeek V3): Bóc tách Giao dịch thường (Thu nhập, Chi phí, Tiết kiệm, Đầu tư).
3. **Agent_Debt** (DeepSeek V3): Bóc tách Công nợ (6 loại: Borrow, Lend, RepayPrincipal, CollectPrincipal, RepayInterest, CollectInterest).
4. **Module_Query** (SQL Thuần): Không gọi LLM. Chỉ dịch tham số từ Router thành lệnh SQL đếm Dư nợ, tính Tổng Thu/Chi.
5. ***(Deferred Phase 3)***: Route Valuation (Định giá thủ công, VD: "Vàng giá 95tr") chưa code, tạm gác lại chờ Phase 3 để không phải đập đi xây lại kiến trúc.

---

## 2. ĐẶC TẢ AGENT ROUTER
Luôn trả về 1 trong 4 nhãn (Labels):
- `Standard`: Giao dịch bình thường (Thu, chi, tiết kiệm, đầu tư).
- `Debt`: Giao dịch nợ, bắt buộc kèm `sub_type`. **BẮT BUỘC trả về lỗi nếu thiếu tham số**: Thiếu tên người -> `{error: "MissingPartner"}`, thiếu số tiền -> `{error: "MissingAmount"}`. KHÔNG ĐƯỢC tự bịa `ma_bp: ""`.
- `Query`: Tra cứu. Phải bóc tách `query_type` (debt, daily, metric) và các tham số phụ (`person`, `date`, `period`).
- `Unclear`: Không rõ ràng. Phải trả kèm `message` hỏi lại user. **Khi user trả lời, frontend phải gửi kèm `context_history[]` (các tin nhắn trước) lên API; Router/Worker đọc đủ ngữ cảnh để tự chốt giao dịch, KHÔNG hỏi lại lần 2 (chống lặp vô tận).**

---

## 3. NGUYÊN TẮC KẾ TOÁN CHUẨN
Khi tính toán báo cáo (Metric) hoặc ghi sổ, tuân thủ nguyên tắc Dòng Tiền và Dịch Chuyển Tài Sản:
- **THU (Tăng tài sản ròng)** = Thu nhập thật + Lãi thu được (`CollectInterest`). *(TUYỆT ĐỐI KHÔNG cộng Thu nợ gốc)*.
- **CHI (Giảm tài sản ròng)** = Chi phí thật + Lãi phải trả (`RepayInterest`). *(TUYỆT ĐỐI KHÔNG cộng Cho vay / Trả nợ gốc)*.
- **GỐC NỢ** (Borrow, Lend, RepayPrincipal, CollectPrincipal): Là luân chuyển tài sản, không ảnh hưởng Thu/Chi. Chỉ dùng để tính Dư Nợ.
- **DƯ NỢ** = `SUM(Lend + RepayPrincipal) - SUM(Borrow + CollectPrincipal)`. (Dương = Họ nợ mình. Âm = Mình nợ họ).

---

## 4. QUY TẮC THỜI GIAN & TIMEZONE
Mọi xử lý ngày giờ trên Server (Vercel) phải ép về múi giờ Việt Nam.
- **Timezone chuẩn:** `UTC+7` (`Asia/Ho_Chi_Minh`). Không dùng `new Date()` trần. Phải dùng hàm `nowVN()`.
- **Date Range:** Một ngày bắt đầu từ `00:00:00` đến `23:59:59.999` (UTC+7).
- **SQL Query:** Truy vấn theo mốc `created_at >= start AND created_at < end` (dùng `< ngày kế tiếp` để không hụt giây 59). Cột trong DB phải là kiểu `timestamptz`.

---

## 5. UI / UX & FRONTEND (NEXT.JS PWA)
- **Bảo mật Passphrase:** Có màn hình đăng nhập tĩnh. Client hash SHA-256. Middleware chặn API nếu sai Hash.
- **Thẻ Xác Nhận (Confirm Card):** Hiện tóm tắt giao dịch có nút `[Thực Hiện]` và `[Hủy]`. Không auto-commit. **Riêng giao dịch Debt, Confirm Card phải có Dropdown đối tác + tùy chọn "✏️ Nhập đối tác mới" → Hiện ô input inline ngay trong thẻ (TUYỆT ĐỐI không dùng `prompt()`).**
- **Hoàn Tác (Undo):** Gọi lệnh Delete truyền đúng `txId`, hoặc gõ phím "Xóa cái vừa rồi".
- **Tiếng Lóng (Slang):** Prompt Worker luôn chứa bảng quy đổi tiền tệ (ca, k, lít, xị, củ, chai, tỏi).

---

## 6. FACT-CHECK TABLE (Bảng Raw Data Inline)
Khi Query Báo cáo, bắt buộc hiển thị Bảng Raw Data ở dưới dạng Toggle.
- **API Response:** `Promise.all` chạy song song 2 Query (1 Aggregate, 1 Raw Data `LIMIT 10`) với **CÙNG 1 `WHERE` CLAUSE**.
  - Trả về JSON: `{ summary, raw_data, total_count }`.
- **UI Bảng:**
  - Nằm inline ngay dưới báo cáo. Mặc định Đóng. Nút toggle: `📋 Xem chi tiết (X giao dịch) ▼`.
  - Cuộn dọc max 10 dòng (height ~320px), cuộn ngang nếu màn hình nhỏ (min-width 420px).
  - Header dính (sticky top). Cột tiền canh phải. Ghi chú truncate.
  - Nếu `total_count === 0` -> Ẩn nút toggle.
  - Nếu `total_count > 10` -> Dưới bảng ghi *"Hiển thị 10/X giao dịch gần nhất"*.

---

## 7. CHI TIẾT CÁC LUỒNG LOGIC (MERMAID FLOWS)

### 7.1. Luồng Bóc Tách & Ghi Sổ Tiêu Dùng (Agent Standard)
```mermaid
graph TD
    A[Tin nhắn User] --> B{Router: Standard}
    B --> C[Agent_Standard bóc tách JSON]
    C --> D{Phân loại}
    
    D -->|Thu nhập| E[Lưu DB: Thu nhập + Lv1 + Lv2]
    D -->|Chi phí| F[Lưu DB: Chi phí + Lv1 + Lv2]
    D -->|Tiết kiệm| G[Lưu DB: Tiết kiệm]
    D -->|Đầu tư| H[Lưu DB: Đầu tư Vốn / Thị giá]

    E --> I[Tăng Tài sản ròng]
    F --> J[Giảm Tài sản ròng]
    G --> K[Không đổi Tài sản ròng, Tăng Tiết kiệm]
    H --> L[Không đổi Tài sản ròng, Tăng Đầu tư]
```

### 7.2. Luồng Bóc Tách & Xử Lý Công Nợ (Agent Debt)
```mermaid
graph TD
    A[Tin nhắn User] --> B{Router: Debt}
    B --> C[Agent_Debt bóc tách JSON]
    C --> D{Xác định Sub-Type}
    
    D -->|Borrow| E[Đi vay: Tăng Tiền, Tăng Nợ phải trả]
    D -->|Lend| F[Cho vay: Giảm Tiền, Tăng Nợ phải thu]
    D -->|RepayPrincipal| G[Trả nợ gốc: Giảm Tiền, Giảm Nợ phải trả]
    D -->|CollectPrincipal| H[Thu nợ gốc: Tăng Tiền, Giảm Nợ phải thu]
    D -->|RepayInterest| I[Trả lãi: Giảm Tiền, Tính vào CHI PHÍ]
    D -->|CollectInterest| J[Thu lãi: Tăng Tiền, Tính vào THU NHẬP]
```

### 7.3. Luồng Tính Toán Báo Cáo & Dòng Tiền (Module Query)
*(Lưu ý cho Gemini: Dưới đây là sơ đồ minh họa, khi implement thực tế bắt buộc tuân thủ công thức Toán học ở Mục §3, đừng implement nhầm theo chữ "Nợ Họ/Họ Nợ" trong Mermaid này).*
```mermaid
graph TD
    A[Yêu cầu Báo cáo] --> B{Query Type}
    B -->|Metric/Daily| C[Tính Dòng Tiền & Tổng Thu/Chi]
    B -->|Debt| D[Tính Dư Nợ Đối Tác]

    C --> C1[Thu = SUM Thu Nhập + SUM CollectInterest]
    C --> C2[Chi = SUM Chi Phí + SUM RepayInterest]
    C --> C3[Dòng Tiền Thuần = Thu - Chi]

    D --> D1[Nợ Họ = SUM Borrow + SUM CollectPrincipal]
    D --> D2[Họ Nợ = SUM Lend + SUM RepayPrincipal]
    D --> D3[Dư Nợ = Họ Nợ - Nợ Họ]
```

---

## 8. CÂY DANH MỤC TIÊU CHUẨN (CATEGORIES TREE)
Để hệ thống AI bóc tách chính xác tuyệt đối, mọi giao dịch Standard phải được map vào cây danh mục chuẩn (dựa trên file `Danh muc.csv`):

- **🟢 THU NHẬP**
  - Lương
  - Thu nhập khác
- **🔴 CHI PHÍ (Các Hạng Mục Lv1 -> Lv2)**
  - **Ăn uống**: Ăn uống, Khác
  - **Hóa đơn**: Điện thoại, Xăng, Nhớt, Momo, Shopee, SCB, Khác
  - **Mua sắm**: Quần áo, Skin care, Đồ gia dụng, Supplement, Học tập, Đồ công nghệ, Khác
  - **Y tế**: Y tế, Khác
  - **Giải trí**: Giải trí, Khác
  - **Hiếu hỉ**: Hiếu hỉ, Khác
  - **Con cái**: Con cái, Khác
  - **Nhà ở**: Nhà ở, Khác
  - **Di chuyển**: Di chuyển, Khác
  - **Quỹ lớp**: Quỹ lớp, Khác
- **🏦 TIẾT KIỆM**
  - Tiết kiệm
  - Khác
- **📈 ĐẦU TƯ (Lv1 luôn là "Đầu tư")**
  - **Đầu tư (Vốn)**: Vàng (Vốn), Chứng khoán (Vốn), Gửi ngân hàng (Vốn), Crypto (Vốn). -> *PhanLoai = "Đầu tư (Vốn)"*
  - **Đầu tư (Thị giá)**: Vàng (Thị giá), Chứng khoán (Thị giá), Gửi ngân hàng (Thị giá), Crypto (Thị giá). -> *PhanLoai = "Đầu tư (Thị giá)"*
  - Khác

---

## 9. DANH SÁCH TÍNH NĂNG & ROADMAP PHÁT TRIỂN

### ✅ PHẦN 1: CÁC TÍNH NĂNG ĐÃ HOÀN THIỆN (PHASE 1 & 2)
1. **Bảo mật PWA:** Đăng nhập bằng Passphrase (băm SHA-256), Cookie bảo vệ API.
2. **Giao diện Chatbot:** Khung chat phong cách Message, vuốt mượt mà, hỗ trợ tiếng lóng (k, củ, tỏi).
3. **Phân loại AI (Router):** Nhận diện 4 ý định: Ghi sổ thường, Ghi sổ nợ, Tra cứu, Không rõ nghĩa.
4. **Ghi sổ Tiêu dùng (Agent Standard):** Bóc tách chính xác Thu/Chi/Tiết kiệm/Đầu tư theo cây Danh Mục.
5. **Ghi sổ Công nợ (Agent Debt):** Bóc tách chính xác 6 loại Gốc & Lãi, nhận diện đối tác (person).
6. **Thẻ Xác Nhận (Confirm Card):** Chặn Auto-commit, hiện UI tóm tắt giao dịch chờ User duyệt (Thực hiện / Hủy).
7. **Hoàn Tác (Undo):** Gọi lệnh xóa giao dịch vừa nhập khi User gõ "Xóa cái vừa rồi".
8. **Truy vấn Dữ liệu (Query SQL):** 
   - Đếm số dư nợ của một đối tác bất kỳ.
   - Tính Tổng Thu, Tổng Chi, Dòng Tiền theo thời gian (Tuần, Tháng, Năm, Hôm qua, Hôm nay).
9. **Inline Fact-Check Table:** Hiển thị Bảng Raw Data (max 10 dòng) ngay dưới thẻ Báo Cáo. Có thể bấm Mở/Gấp gọn.

### 🚀 PHẦN 2: CÁC TÍNH NĂNG SẼ TRIỂN KHAI TIẾP THEO (PHASE 3, 4, 5)
1. **[Phase 3] Biểu Đồ Trực Quan (Charts):**
   - Tích hợp thư viện Recharts để hiển thị biểu đồ Tròn (Cơ cấu chi phí), biểu đồ Cột (Thu vs Chi) inline ngay trong dòng Chat khi sếp có yêu cầu báo cáo.
2. **[Phase 4] Nhắc Nợ & Thông Báo Push:**
   - Setup Cronjob quét database xem ai đang nợ quá hạn.
   - Bắn thông báo Push Notification (PWA) thẳng xuống điện thoại. *(Caveat: Trên iOS, PWA Push Notification chỉ chạy từ iOS 16.4+ và bắt buộc user phải "Add to Home Screen")*.
3. **[Phase 5] Macro-Finance Dashboard & AI Cố Vấn Vĩ Mô:**
   - Xây dựng một bảng theo dõi các chỉ báo tài chính vĩ mô (Financial Indicators).
   - Phân tích và xác định các chu kỳ kinh tế (ví dụ: Suy thoái, Bơm tiền).
   - Phát hiện các thay đổi về chính sách tiền tệ (Monetary Policies) ảnh hưởng tới tài sản.
   - Tích hợp thêm **1 Agent AI Tài chính siêu thông minh** (Chuyên gia Vĩ mô) để đưa ra cái nhìn tổng quan và lời khuyên chiến lược. *(Dành riêng cho giai đoạn tài sản đã tích lũy đủ lớn để tham gia đầu tư tài chính)*.

---

## 10. QUY TRÌNH PHỐI HỢP AI TỐI ƯU (WORKFLOW BOUNDARIES)
Để tăng tốc độ phát triển dự án và giảm tải thao tác copy/paste thủ công, quy trình phối hợp giữa User (Giám đốc), Claude (Kiến trúc sư) và Gemini (Kỹ sư thi công) được quy định rõ:

### 🟢 Vùng Gemini tự động hóa 100%:
- Đọc hiểu Blueprint/Checklist từ User và chui thẳng vào Local Workspace để viết code, sửa file, tạo component mới.
- Đọc lỗi (Bug) nếu có log và tự động refactor không cần hướng dẫn từng dòng.
- *(Tương lai)*: Tự động chạy lệnh `git commit` và `git push` để tự Deploy lên Vercel nếu máy User có cài Git.

### 🔴 Vùng User cần làm "Cầu nối" (Truyền tải thông tin):
- **Giao tiếp Claude:** Gemini không có quyền truy cập chéo sang Claude. User bắt buộc phải copy thiết kế/review của Claude và thả vào ngữ cảnh của Gemini.
- **Test UI / UX Thực tế:** Gemini không thể nhìn thấy màn hình điện thoại hay bấm vuốt app PWA. User phải là QA Tester để chạy thử luồng, kiểm tra giao diện (CSS) và đối chiếu số liệu thật.
- **Deploy thủ công (Tạm thời):** Kéo thả thư mục dự án lên Github web để Vercel build (cho đến khi máy cài Git).

---

## 11. ERROR HANDLING & VALIDATION (Bắt buộc)
Ứng dụng tài chính tuyệt đối KHÔNG tin tưởng 100% output của LLM.
- **LLM Sập/Timeout:** Nếu Groq hoặc DeepSeek lỗi/timeout, API phải trả về HTTP 500 kèm thông báo UI rõ ràng: *"Hệ thống AI đang quá tải, vui lòng thử lại sau"*. Tuyệt đối không crash server.
- **JSON Hỏng (Parse Error):** Nếu LLM trả text rác không thể `JSON.parse`, phải catch lỗi và báo UI: *"Dữ liệu AI trả về bị lỗi định dạng"*.
- **Validation Server-side (Trước khi INSERT DB):**
  - `so_tien` phải là số. Phải > 0 (ngoại trừ trường hợp rút tiết kiệm có thể âm/cộng dồn).
  - `phan_loai` phải match 100% với danh sách trong Cây Danh Mục (§8). Nếu sai, báo lỗi từ chối INSERT.
  - `date` phải là ISO string hợp lệ.

---

## CHANGELOG
- [2026-06-06] Khởi tạo Specs và Workflow Protocol.
- [2026-06-06] Vá 6 lỗ hổng: Thêm §11 Error Handling; Vá `context_history` cho luồng Unclear (§2); Thêm output lỗi `MissingPartner/Amount` cho Debt (§2); Thêm ô nhập đối tác mới inline (§5); Clarify PhanLoai Đầu tư (§8); Sửa typo & lưu ý iOS PWA (§7, §9).
- [2026-06-07] Thêm §12 Đặc tả Giao diện Chat 2-Bit Brutalist chuẩn bị cho Phase 3.

---

## 12. GIAO DIỆN CHAT 2-BIT BRUTALIST (UI SPECS)

Để chuẩn bị cho việc nâng cấp UI/UX, phần UI của App được quy định theo phong cách **2-Bit Dark Terminal Brutalism**. Toàn bộ cấu trúc giao diện chat đã được tổng hợp thành một file HTML/CSS duy nhất để Claude (hoặc AI Frontend Engineer) dễ dàng tham chiếu và tái hiện thành các React Components.

### 12.1. Ngôn ngữ thiết kế (Design System)
- **Màu sắc:** Bắt buộc chỉ dùng 2 màu chủ đạo: Đen tuyền (`#000000`) làm nền và Xanh chanh Neon (`#C2F500`) làm điểm nhấn/viền/chữ. Nhấn nhá thêm Trắng/Xám nhạt (`#E5E5E5`) cho bong bóng chat của Assistant để tạo tương phản. Không xài gradient hay drop-shadow mềm.
- **Typography:** Dùng font `VT323` cho toàn bộ chữ trên giao diện. Font này tạo cảm giác pixel 8-bit gai góc nhưng vẫn hiển thị hoàn hảo dấu Tiếng Việt. 
- **Hình khối (Shapes):** Tất cả các bong bóng chat, nút bấm, ô input đều phải bẻ cong bất đối xứng kiểu "giọt mực" (squircle blob) bằng thuộc tính `border-radius` chéo (ví dụ: `20px 10px 30px 20px / 20px 15px 25px 20px`).
- **Iconography:** Chỉ dùng SVG tĩnh định dạng pixel thô (set `shape-rendering: crispEdges`).
- **Hình động Nền (Easter Eggs):** Sử dụng kỹ thuật đổ bóng hộp (`box-shadow`) để vẽ các nhân vật 8-bit (Mario chạy, Khủng long nhảy, Ryu bắn chưởng, Claude thả bom) chạy ngầm dưới nền chat. Cần đặt `z-index` thấp, `opacity: 0.2` và `pointer-events: none` để không cản trở thao tác chat.

### 12.2. Mã nguồn tham chiếu (HTML/CSS)
Dưới đây là nguyên mẫu Vanilla HTML/CSS đã được chốt (tỷ lệ chuẩn iPhone 390x844). **Claude có nhiệm vụ đọc, hiểu cấu trúc này và chuyển hóa nó thành UI Components (Next.js / Tailwind CSS) khi được yêu cầu.**

<details>
<summary><b>Nhấn để xem Source Code Giao diện 2-Bit Brutalist</b></summary>

```html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>2-Bit Brutalist Chat UI</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&family=VT323&display=swap" rel="stylesheet">
<style>
  :root {
    --lime: #C2F500;
    --black: #000000;
    --white: #FFFFFF;
    --light-grey: #E5E5E5;
    --dim-lime: rgba(194, 245, 0, 0.2);
  }

  * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
  }

  body {
    background-color: #222;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    font-family: 'VT323', monospace;
    color: var(--white);
    font-size: 18px;
  }

  /* Phone Mockup Canvas */
  .canvas {
    width: 390px;
    height: 844px;
    background-color: var(--black);
    position: relative;
    overflow: hidden;
    border: 4px solid var(--lime);
    border-radius: 40px; 
    display: flex;
    flex-direction: column;
  }

  /* Status Bar */
  .status-bar {
    display: flex;
    justify-content: space-between;
    padding: 14px 24px;
    font-size: 10px;
    color: var(--lime);
    align-items: center;
    z-index: 10;
  }
  .status-bar-icons svg {
    height: 10px;
    margin-left: 6px;
    fill: var(--lime);
    shape-rendering: crispEdges;
  }

  /* Header */
  .header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 24px 20px;
    border-bottom: 4px solid var(--lime);
    z-index: 10;
  }
  
  .header-title {
    font-family: 'VT323', monospace;
    font-size: 28px;
    color: var(--lime);
    text-transform: uppercase;
    line-height: 1;
  }

  .concept-tag {
    font-size: 14px;
    background: var(--lime);
    color: var(--black);
    padding: 4px 6px;
  }

  /* Chat Area */
  .chat-area {
    flex: 1;
    overflow-y: auto;
    padding: 24px 20px;
    display: flex;
    flex-direction: column;
    gap: 20px;
    z-index: 5;
  }

  .chat-area::-webkit-scrollbar {
    width: 0px;
  }

  /* Message Bubbles */
  .msg-row {
    display: flex;
    width: 100%;
  }

  .msg-row.user {
    justify-content: flex-end;
  }

  .msg-row.assistant {
    justify-content: flex-start;
  }

  .bubble {
    padding: 16px;
    line-height: 1.6;
    max-width: 85%;
    position: relative;
    border: 3px solid transparent;
  }

  /* User Bubble */
  .bubble.user {
    background-color: var(--lime);
    color: var(--black);
    border-radius: 20px 10px 30px 20px / 20px 15px 25px 20px;
  }

  /* Assistant Bubble */
  .bubble.assistant {
    background-color: var(--light-grey);
    color: var(--black);
    border-radius: 10px 30px 20px 30px / 15px 20px 30px 20px;
  }

  /* Brutalist Confirm Card */
  .confirm-card {
    background-color: var(--black) !important;
    border: 3px solid var(--lime) !important;
    color: var(--lime) !important;
    border-radius: 20px 30px 15px 25px / 25px 20px 30px 15px !important;
    padding: 16px !important;
    width: 100%;
    max-width: 100%;
  }

  .confirm-card .card-title {
    font-size: 22px;
    margin-bottom: 16px;
    color: var(--white);
  }

  .confirm-card .card-row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 12px;
    font-size: 16px;
  }
  .confirm-card .card-val {
    color: var(--white);
  }
  .confirm-card .card-val.amount {
    font-size: 22px;
    color: var(--lime);
  }

  .action-buttons {
    display: flex;
    gap: 12px;
    margin-top: 24px;
  }

  .btn {
    flex: 1;
    padding: 12px 8px;
    font-family: 'VT323', monospace;
    font-size: 18px;
    border: none;
    cursor: pointer;
    text-align: center;
  }

  .btn-confirm {
    background-color: var(--lime);
    color: var(--black);
    border-radius: 10px 15px 5px 20px / 15px 10px 20px 5px;
  }

  .btn-cancel {
    background-color: var(--white);
    color: var(--black);
    border-radius: 20px 5px 15px 10px / 10px 20px 5px 15px;
  }

  /* Input Area */
  .input-area {
    padding: 16px 20px 30px;
    background-color: var(--black);
    border-top: 4px solid var(--lime);
    z-index: 10;
  }

  .input-blob {
    display: flex;
    align-items: center;
    background-color: var(--black);
    border: 3px solid var(--lime);
    border-radius: 20px 25px 15px 30px / 25px 20px 30px 15px;
    padding: 6px 6px 6px 16px;
  }

  .input-blob input {
    flex: 1;
    background: transparent;
    border: none;
    outline: none;
    color: var(--lime);
    font-family: 'VT323', monospace;
    font-size: 18px;
  }
  
  .input-blob input::placeholder {
    color: rgba(194, 245, 0, 0.5);
  }

  .send-btn {
    background-color: var(--lime);
    width: 36px;
    height: 36px;
    border-radius: 10px 15px 12px 20px / 15px 10px 20px 12px;
    display: flex;
    justify-content: center;
    align-items: center;
    border: none;
    cursor: pointer;
  }

  .send-btn svg {
    width: 16px;
    height: 16px;
    fill: var(--black);
    shape-rendering: crispEdges;
  }

  /* =========================================
     2-BIT BACKGROUND ANIMATIONS 
     ========================================= */
  .bg-animations {
    position: absolute;
    top: 0; left: 0; width: 100%; height: 100%;
    z-index: 1;
    pointer-events: none;
    overflow: hidden;
  }

  .sprite {
    position: absolute;
    width: 4px; height: 4px;
    background: transparent;
    color: var(--dim-lime);
  }

  /* Street Fighter (Ryu Hadouken Pose) */
  .street-fighter {
    top: 40%;
    left: 20px;
    box-shadow:
      16px 0, 20px 0, 24px 0, 28px 0,
      12px 4px, 16px 4px, 20px 4px, 24px 4px, 28px 4px, 32px 4px,
      12px 8px, 16px 8px, 20px 8px, 24px 8px, 28px 8px, 32px 8px, 36px 8px,
      16px 12px, 20px 12px, 24px 12px, 28px 12px,
      16px 16px, 20px 16px, 24px 16px, 28px 16px,
      12px 20px, 16px 20px, 20px 20px, 24px 20px, 28px 20px, 32px 20px, 36px 20px, 40px 20px,
      8px 24px, 12px 24px, 16px 24px, 20px 24px, 24px 24px, 28px 24px, 32px 24px, 36px 24px, 40px 24px, 44px 24px,
      0px 28px, 4px 28px, 8px 28px, 12px 28px, 16px 28px, 20px 28px, 24px 28px, 28px 28px, 32px 28px, 36px 28px, 40px 28px,
      12px 32px, 16px 32px, 20px 32px, 24px 32px, 28px 32px, 32px 32px, 36px 32px,
      16px 36px, 20px 36px, 24px 36px, 28px 36px, 32px 36px,
      16px 40px, 20px 40px, 28px 40px, 32px 40px,
      16px 44px, 20px 44px, 28px 44px, 32px 44px,
      12px 48px, 16px 48px, 32px 48px, 36px 48px;
  }

  /* Hadouken Fireball */
  .hadouken {
    top: calc(40% + 20px);
    left: 80px;
    box-shadow:
      8px 0, 12px 0, 16px 0, 20px 0, 24px 0,
      4px 4px, 8px 4px, 12px 4px, 16px 4px, 20px 4px, 24px 4px, 28px 4px,
      0px 8px, 4px 8px, 8px 8px, 12px 8px, 16px 8px, 20px 8px, 24px 8px, 28px 8px, 32px 8px, 36px 8px,
      4px 12px, 8px 12px, 12px 12px, 16px 12px, 20px 12px, 24px 12px, 28px 12px,
      8px 16px, 12px 16px, 16px 16px, 20px 16px, 24px 16px;
    animation: shoot 3s infinite linear;
  }
  @keyframes shoot {
    0% { left: 80px; opacity: 1; }
    60% { left: 350px; opacity: 1; }
    61% { opacity: 0; }
    100% { left: 350px; opacity: 0; }
  }

  /* Mario Running */
  .mario {
    bottom: 150px;
    left: -50px;
    box-shadow: 
      12px 0, 16px 0, 20px 0, 24px 0, 28px 0,
      8px 4px, 12px 4px, 16px 4px, 20px 4px, 24px 4px, 28px 4px, 32px 4px, 36px 4px,
      8px 8px, 12px 8px, 16px 8px, 20px 8px, 24px 8px, 28px 8px,
      8px 12px, 12px 12px, 16px 12px, 20px 12px, 24px 12px,
      12px 16px, 16px 16px, 20px 16px, 24px 16px,
      8px 20px, 12px 20px, 16px 20px, 20px 20px, 24px 20px, 28px 20px, 32px 20px,
      4px 24px, 8px 24px, 12px 24px, 16px 24px, 20px 24px, 24px 24px, 28px 24px, 32px 24px, 36px 24px,
      0px 28px, 4px 28px, 8px 28px, 16px 28px, 24px 28px, 32px 28px, 36px 28px, 40px 28px,
      12px 32px, 16px 32px, 24px 32px, 28px 32px,
      8px 36px, 12px 36px, 28px 36px, 32px 36px;
    animation: runRight 8s infinite linear;
  }
  @keyframes runRight {
    0% { left: -50px; }
    100% { left: 450px; }
  }

  /* Dino Jumping */
  .dino {
    bottom: 250px;
    right: -50px;
    box-shadow:
      32px 0, 36px 0, 40px 0, 44px 0, 48px 0,
      32px 4px, 36px 4px, 40px 4px, 44px 4px, 48px 4px, 52px 4px,
      32px 8px, 36px 8px, 40px 8px,
      32px 12px, 36px 12px, 40px 12px, 44px 12px, 48px 12px,
      32px 16px, 36px 16px, 40px 16px, 44px 16px, 48px 16px,
      32px 20px, 36px 20px, 40px 20px,
      4px 24px, 32px 24px, 36px 24px,
      4px 28px, 8px 28px, 28px 28px, 32px 28px,
      4px 32px, 8px 32px, 12px 32px, 16px 32px, 20px 32px, 24px 32px, 28px 32px, 32px 32px,
      4px 36px, 8px 36px, 12px 36px, 16px 36px, 20px 36px, 24px 36px, 28px 36px, 32px 36px,
      4px 40px, 8px 40px, 12px 40px, 16px 40px, 20px 40px, 24px 40px, 28px 40px,
      8px 44px, 12px 44px, 16px 44px, 20px 44px, 24px 44px, 28px 44px,
      12px 48px, 16px 48px, 20px 48px,
      12px 52px, 16px 52px,
      12px 56px, 20px 56px,
      12px 60px, 20px 60px;
    animation: runLeft 10s infinite linear, jump 2.5s infinite ease-out;
  }
  @keyframes runLeft {
    0% { right: -60px; }
    100% { right: 450px; }
  }
  @keyframes jump {
    0%, 80%, 100% { transform: translateY(0); }
    90% { transform: translateY(-60px); }
  }

  /* Claude Robot */
  .claude {
    top: 80px;
    left: -60px;
    box-shadow:
      16px 0, 20px 0, 24px 0, 28px 0,
      12px 4px, 16px 4px, 20px 4px, 24px 4px, 28px 4px, 32px 4px,
      8px 8px, 12px 8px, 16px 8px, 20px 8px, 24px 8px, 28px 8px, 32px 8px, 36px 8px,
      8px 12px, 12px 12px, 16px 12px, 20px 12px, 24px 12px, 28px 12px, 32px 12px, 36px 12px,
      8px 16px, 12px 16px, 16px 16px, 28px 16px, 32px 16px, 36px 16px,
      8px 20px, 12px 20px, 16px 20px, 20px 20px, 24px 20px, 28px 20px, 32px 20px, 36px 20px,
      12px 24px, 16px 24px, 20px 24px, 24px 24px, 28px 24px, 32px 24px,
      16px 28px, 20px 28px, 24px 28px, 28px 28px,
      20px 32px, 24px 32px;
    animation: flyRight 15s infinite linear;
  }
  @keyframes flyRight {
    0% { left: -60px; }
    100% { left: 450px; }
  }

  /* Bomb */
  .bomb {
    animation: dropBomb 15s infinite linear;
  }
  @keyframes dropBomb {
    0%, 40% { top: 80px; left: -100px; opacity: 0; }
    41% { top: 110px; left: 160px; opacity: 1; }
    46% { top: 850px; left: 160px; opacity: 1; }
    47%, 100% { top: 850px; opacity: 0; }
  }
  .bomb-sprite {
    box-shadow:
      12px 0, 16px 0,
      8px 4px, 12px 4px, 16px 4px, 20px 4px,
      4px 8px, 8px 8px, 12px 8px, 16px 8px, 20px 8px, 24px 8px,
      4px 12px, 8px 12px, 12px 12px, 16px 12px, 20px 12px, 24px 12px,
      4px 16px, 8px 16px, 12px 16px, 16px 16px, 20px 16px, 24px 16px,
      8px 20px, 12px 20px, 16px 20px, 20px 20px,
      12px 24px, 16px 24px;
  }

</style>
</head>
<body>

<div class="canvas">
  
  <!-- BACKGROUND ANIMATIONS -->
  <div class="bg-animations">
    <div class="sprite street-fighter"></div>
    <div class="sprite hadouken"></div>
    <div class="sprite mario"></div>
    <div class="sprite dino"></div>
    <div class="sprite claude"></div>
    <div class="sprite bomb"><div class="sprite bomb-sprite"></div></div>
  </div>

  <!-- Status Bar -->
  <div class="status-bar">
    <span>9:41</span>
    <div class="status-bar-icons">
      <svg viewBox="0 0 16 12"><path d="M0 8h3v4H0zm4-3h3v7H4zm4-3h3v10H8zm4-2h3v12h-3z"/></svg>
      <svg viewBox="0 0 16 12"><path d="M8 9l-2 3h4l-2-3zm0-3l-4 5c2 2 6 2 8 0l-4-5zm0-3L2 6c3 3 9 3 12 0L8 3zm0-3L0 4c4 4 12 4 16 0L8 0z"/></svg>
      <svg viewBox="0 0 20 12"><path d="M1 1h16v10H1V1zm1 1v8h14V2H2zm15 3h2v4h-2V5z"/></svg>
    </div>
  </div>

  <!-- Header -->
  <div class="header">
    <div class="header-title">FIN_CHAT</div>
    <div class="concept-tag">// RAW</div>
  </div>

  <!-- Chat Area -->
  <div class="chat-area">
    
    <div class="msg-row assistant">
      <div class="bubble assistant">
        Chào sếp! Hôm nay sếp muốn ghi sổ hay tra cứu tài chính gì ạ?
      </div>
    </div>

    <div class="msg-row user">
      <div class="bubble user">
        Vay Tùng 500k
      </div>
    </div>

    <div class="msg-row assistant">
      <div class="bubble assistant confirm-card">
        <div class="card-title">CONFIRM TX</div>
        <div class="card-row">
          <span>TYPE:</span>
          <span class="card-val">BORROW</span>
        </div>
        <div class="card-row">
          <span>PARTNER:</span>
          <span class="card-val">TÙNG</span>
        </div>
        <div class="card-row">
          <span>AMOUNT:</span>
          <span class="card-val amount">500,000 đ</span>
        </div>
        
        <div class="action-buttons">
          <button class="btn btn-confirm">THỰC HIỆN</button>
          <button class="btn btn-cancel">HỦY BỎ</button>
        </div>
      </div>
    </div>

    <div class="msg-row user">
      <div class="bubble user">
        Chuyển 2 củ
      </div>
    </div>

    <div class="msg-row assistant">
      <div class="bubble assistant">
        Sếp chuyển cho việc gì ạ?
      </div>
    </div>

  </div>

  <!-- Input Area -->
  <div class="input-area">
    <div class="input-blob">
      <input type="text" placeholder="TYPE HERE..." value="Mua gạo 100">
      <button class="send-btn">
        <!-- Pixel Arrow SVG -->
        <svg viewBox="0 0 16 16">
          <path d="M0 6h8V4h2V2h2V0h2v2h-2v2h-2v2h2v2h2v2h-2v2h-2v2h-2v2H8v-2h2v-2h2v-2H0V6z"/>
        </svg>
      </button>
    </div>
  </div>

</div>

</body>
</html>
```
</details>


